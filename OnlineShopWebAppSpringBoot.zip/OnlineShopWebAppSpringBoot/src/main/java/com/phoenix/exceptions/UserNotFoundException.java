package com.phoenix.exceptions;
/*
 * Parshwa Sheth
 * Exception
 * */
public class UserNotFoundException extends Exception {
	
	
	private String message;

	public UserNotFoundException(String message) {
		super();
		this.message = message;
	}

	@Override
	public String toString() {
		return "UserNotFoundException [message=" + message + "]";
	}
	
	

}
